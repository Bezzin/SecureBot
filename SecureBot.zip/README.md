# MoltBot Secure Setup Wizard 🦞🔐

A beginner-friendly installer that sets up MoltBot with security best practices, even if you're not technical.

## What This Does

This wizard automates all the complex security configuration from the [full guide](moltbot-security-guide.md), including:

- ✅ Installing all dependencies (Node.js, Docker)
- ✅ Configuring firewall rules
- ✅ Setting up Tailscale VPN (optional)
- ✅ Installing MoltBot
- ✅ Configuring Kimi K2.5 via OpenRouter
- ✅ Enabling Docker sandboxing
- ✅ Generating secure authentication tokens
- ✅ Setting up WhatsApp/Telegram with safe defaults
- ✅ Running security audit

## Quick Start

### One-Line Install

```bash
curl -fsSL https://raw.githubusercontent.com/YOUR_REPO/moltbot-secure-setup.sh | bash
```

### Manual Install

```bash
# Download the script
curl -O https://raw.githubusercontent.com/YOUR_REPO/moltbot-secure-setup.sh

# Make it executable
chmod +x moltbot-secure-setup.sh

# Run it
./moltbot-secure-setup.sh
```

## Requirements

- **Ubuntu 22.04+** or **Debian 12+** (recommended)
- macOS also supported (some features may vary)
- A user account with sudo access
- **NOT** running as root

## What You'll Need

Before running the wizard, have these ready:

1. **OpenRouter API Key**
   - Go to https://openrouter.ai
   - Create account → Keys → Create Key
   - Copy the key (starts with `sk-or-...`)

2. **Dedicated Phone Number** (for WhatsApp)
   - Google Voice (free, US only)
   - Twilio (~$1/month)
   - Prepaid SIM card
   - ⚠️ **DO NOT use your personal number!**

3. **Brave Search API Key** (optional, for web search)
   - Go to https://brave.com/search/api/
   - Free tier: 2,000 queries/month

## Security Levels

The wizard offers three security profiles:

| Level | Sandboxing | File Access | Browser | Best For |
|-------|------------|-------------|---------|----------|
| **Maximum** 🔒 | All tools | Read-only | Disabled | Most users |
| **Balanced** ⚖️ | Non-main | Read/write | Disabled | Power users |
| **Minimal** ⚠️ | Disabled | Full | Enabled | Testing only |

**Recommendation:** Start with Maximum and loosen only if needed.

## What Happens During Setup

```
1. System Check
   └── Verifies OS, permissions, dependencies

2. Install Dependencies  
   ├── Node.js 22
   ├── Docker
   └── MoltBot

3. Firewall Setup
   ├── Block all incoming (except SSH)
   ├── Fix Docker UFW bypass
   └── Allow Tailscale (if enabled)

4. Tailscale Setup (optional)
   └── Encrypted VPN access

5. Configuration
   ├── OpenRouter API key
   ├── Security level selection
   ├── Web access settings
   └── Channel selection

6. Generate Secure Config
   ├── Random gateway token
   ├── Sandbox settings
   └── Secure file permissions

7. Channel Setup
   ├── WhatsApp pairing
   └── Telegram bot token

8. Security Audit
   └── Verify configuration

9. Start MoltBot
   └── Run as systemd service
```

## After Installation

### Access Your MoltBot

**Local:** http://127.0.0.1:18789

**Via Tailscale:** http://YOUR_TAILSCALE_IP:18789

### Approve WhatsApp Contacts

```bash
# View pending requests
moltbot pairing list whatsapp

# Approve a contact
moltbot pairing approve whatsapp ABC123
```

### Useful Commands

```bash
moltbot gateway              # Start MoltBot
moltbot security audit       # Check security
moltbot status               # View status
moltbot doctor               # Diagnose issues
moltbot pairing list         # View pending approvals
```

## Troubleshooting

### "Permission denied"

```bash
# Make sure you're not root
whoami  # Should NOT be "root"

# Check sudo access
sudo -v
```

### "Docker permission denied"

```bash
# Add yourself to docker group
sudo usermod -aG docker $USER

# Log out and back in, or run:
newgrp docker
```

### "MoltBot won't start"

```bash
# Check the service status
sudo systemctl status moltbot

# View logs
moltbot logs --tail 50
```

### "Can't access web dashboard"

```bash
# Check if gateway is running
curl http://127.0.0.1:18789/health

# If using Tailscale, check connection
tailscale status
```

## Updating

```bash
# Update MoltBot
npm update -g moltbot

# Re-run security audit
moltbot security audit
```

## Uninstalling

```bash
# Stop the service
sudo systemctl stop moltbot
sudo systemctl disable moltbot

# Remove MoltBot
npm uninstall -g moltbot

# Remove configuration (optional - contains your data!)
rm -rf ~/.moltbot

# Remove service file
sudo rm /etc/systemd/system/moltbot.service
```

## Security Notes

⚠️ **Important reminders:**

1. **Never use personal accounts** - Always create dedicated email, phone, WhatsApp
2. **Save your gateway token** - You'll need it to access the dashboard
3. **Run security audits regularly** - `moltbot security audit --deep`
4. **Keep MoltBot updated** - `npm update -g moltbot`
5. **Monitor your API costs** - Check OpenRouter dashboard regularly

## Support

- **Official Docs:** https://docs.molt.bot
- **Security Guide:** https://docs.molt.bot/gateway/security
- **GitHub Issues:** https://github.com/moltbot/moltbot/issues

---

*Built with security in mind. Stay safe! 🦞🔐*
