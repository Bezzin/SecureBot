#!/bin/bash

#===============================================================================
#   MoltBot Quick Start - Minimal Prompts Edition
#   For users who just want secure defaults with minimal questions
#===============================================================================

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${CYAN}"
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║  🦞 MoltBot Quick Start - Maximum Security Defaults            ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# Check not root
if [ "$EUID" -eq 0 ]; then
    echo -e "${RED}Error: Don't run as root. Use a regular user with sudo.${NC}"
    exit 1
fi

# Get OpenRouter key upfront
echo -e "${YELLOW}You'll need an OpenRouter API key.${NC}"
echo "Get one at: https://openrouter.ai (Keys → Create Key)"
echo ""
read -sp "Paste your OpenRouter API key (sk-or-...): " OPENROUTER_KEY
echo ""

if [[ ! "$OPENROUTER_KEY" =~ ^sk-or- ]]; then
    echo -e "${RED}Invalid key format. Should start with sk-or-${NC}"
    exit 1
fi

echo ""
echo -e "${CYAN}Installing with maximum security defaults...${NC}"
echo ""

# Install Node.js if needed
if ! command -v node &> /dev/null || [ "$(node -v | cut -d'v' -f2 | cut -d'.' -f1)" -lt 22 ]; then
    echo "Installing Node.js 22..."
    curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
    sudo apt-get install -y nodejs
fi

# Install Docker if needed
if ! command -v docker &> /dev/null; then
    echo "Installing Docker..."
    curl -fsSL https://get.docker.com | sudo sh
    sudo usermod -aG docker $USER
fi

# Install MoltBot
echo "Installing MoltBot..."
npm install -g moltbot@latest

# Generate secure token
GATEWAY_TOKEN=$(openssl rand -base64 32 | tr -d '/+=' | head -c 32)

# Create secure config
mkdir -p ~/.moltbot
cat > ~/.moltbot/moltbot.json << EOF
{
  "env": { "OPENROUTER_API_KEY": "$OPENROUTER_KEY" },
  "gateway": {
    "bind": "loopback",
    "port": 18789,
    "auth": { "mode": "token", "token": "$GATEWAY_TOKEN" }
  },
  "discovery": { "mdns": { "mode": "minimal" } },
  "agents": {
    "defaults": {
      "model": { "primary": "openrouter/moonshotai/kimi-k2.5" },
      "sandbox": { "mode": "all", "scope": "session", "workspaceAccess": "ro" }
    }
  },
  "tools": {
    "elevated": { "allowFrom": [] },
    "browser": { "enabled": false }
  },
  "channels": {
    "whatsapp": { "dmPolicy": "pairing", "groups": { "*": { "requireMention": true } } }
  },
  "logging": { "redactSensitive": "tools" }
}
EOF
chmod 700 ~/.moltbot
chmod 600 ~/.moltbot/moltbot.json

# Configure firewall
if command -v ufw &> /dev/null; then
    echo "Configuring firewall..."
    sudo ufw default deny incoming
    sudo ufw default allow outgoing
    sudo ufw allow ssh
    sudo ufw --force enable
fi

echo ""
echo -e "${GREEN}════════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}  ✓ MoltBot installed with maximum security!${NC}"
echo -e "${GREEN}════════════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "  Gateway Token: ${YELLOW}$GATEWAY_TOKEN${NC}"
echo -e "  ${RED}↑ SAVE THIS! You need it for the dashboard${NC}"
echo ""
echo "  Start MoltBot:  moltbot gateway"
echo "  Dashboard:      http://127.0.0.1:18789"
echo "  Security check: moltbot security audit"
echo ""
echo -e "${CYAN}For WhatsApp: Use a DEDICATED number, not personal!${NC}"
echo ""
