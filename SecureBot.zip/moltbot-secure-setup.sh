#!/bin/bash

#===============================================================================
#
#   MoltBot Secure Setup Wizard
#   Security-First Installation for Non-Technical Users
#
#   Author: Claude
#   Version: 1.0
#   Date: January 2026
#
#===============================================================================

set -e

# Colors and formatting
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
GRAY='\033[0;90m'
NC='\033[0m' # No Color
BOLD='\033[1m'
DIM='\033[2m'

# Configuration variables (set during wizard)
OPENROUTER_API_KEY=""
GATEWAY_TOKEN=""
BRAVE_API_KEY=""
ENABLE_WEB_SEARCH=false
ENABLE_WHATSAPP=false
ENABLE_TELEGRAM=false
INSTALL_TAILSCALE=false
SECURITY_LEVEL="maximum"  # maximum, balanced, minimal

# State file for resume capability
STATE_FILE="$HOME/.moltbot-setup-state"
CONFIG_DIR="$HOME/.moltbot"
CONFIG_FILE="$CONFIG_DIR/moltbot.json"

#===============================================================================
# UTILITY FUNCTIONS
#===============================================================================

print_banner() {
    clear
    echo -e "${CYAN}"
    cat << "EOF"
    ╔═══════════════════════════════════════════════════════════════════╗
    ║                                                                   ║
    ║   🦞  MoltBot Secure Setup Wizard                                ║
    ║                                                                   ║
    ║   Security-First • Beginner-Friendly • Fully Automated           ║
    ║                                                                   ║
    ╚═══════════════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"
}

print_section() {
    echo ""
    echo -e "${PURPLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${WHITE}${BOLD}  $1${NC}"
    echo -e "${PURPLE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
}

print_step() {
    echo -e "${CYAN}▶${NC} $1"
}

print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

print_tip() {
    echo -e "${GRAY}  💡 $1${NC}"
}

# Animated progress indicator
spinner() {
    local pid=$1
    local delay=0.1
    local spinstr='⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏'
    while [ "$(ps a | awk '{print $1}' | grep $pid)" ]; do
        local temp=${spinstr#?}
        printf " ${CYAN}%c${NC}  " "$spinstr"
        local spinstr=$temp${spinstr%"$temp"}
        sleep $delay
        printf "\b\b\b\b"
    done
    printf "    \b\b\b\b"
}

# Run command with spinner
run_with_spinner() {
    local message="$1"
    shift
    echo -ne "${CYAN}▶${NC} $message... "
    
    # Run command in background
    "$@" > /tmp/moltbot-setup-output.log 2>&1 &
    local pid=$!
    spinner $pid
    wait $pid
    local status=$?
    
    if [ $status -eq 0 ]; then
        echo -e "${GREEN}✓${NC}"
        return 0
    else
        echo -e "${RED}✗${NC}"
        echo -e "${RED}Error output:${NC}"
        cat /tmp/moltbot-setup-output.log
        return 1
    fi
}

# Ask yes/no question with default
ask_yes_no() {
    local prompt="$1"
    local default="$2"
    
    if [ "$default" = "y" ]; then
        prompt="$prompt [Y/n]: "
    else
        prompt="$prompt [y/N]: "
    fi
    
    while true; do
        echo -ne "${WHITE}$prompt${NC}"
        read -r response
        response=${response:-$default}
        case "$response" in
            [Yy]* ) return 0;;
            [Nn]* ) return 1;;
            * ) echo -e "${YELLOW}Please answer yes or no.${NC}";;
        esac
    done
}

# Ask for input with validation
ask_input() {
    local prompt="$1"
    local default="$2"
    local is_secret="$3"
    local validation="$4"
    
    while true; do
        if [ -n "$default" ]; then
            echo -ne "${WHITE}$prompt [${default}]: ${NC}"
        else
            echo -ne "${WHITE}$prompt: ${NC}"
        fi
        
        if [ "$is_secret" = "true" ]; then
            read -rs response
            echo ""
        else
            read -r response
        fi
        
        response=${response:-$default}
        
        # Validation
        if [ -n "$validation" ]; then
            case "$validation" in
                "nonempty")
                    if [ -z "$response" ]; then
                        print_error "This field cannot be empty."
                        continue
                    fi
                    ;;
                "api_key")
                    if [[ ! "$response" =~ ^sk-or- ]]; then
                        print_error "OpenRouter API keys start with 'sk-or-'"
                        continue
                    fi
                    ;;
            esac
        fi
        
        echo "$response"
        return 0
    done
}

# Menu selection
select_option() {
    local prompt="$1"
    shift
    local options=("$@")
    local selected=0
    local key=""
    
    echo -e "${WHITE}$prompt${NC}"
    echo ""
    
    # Hide cursor
    tput civis
    
    while true; do
        # Print options
        for i in "${!options[@]}"; do
            if [ $i -eq $selected ]; then
                echo -e "  ${CYAN}▸ ${WHITE}${options[$i]}${NC}"
            else
                echo -e "    ${GRAY}${options[$i]}${NC}"
            fi
        done
        
        # Read single keypress
        read -rsn1 key
        
        # Handle arrow keys (they send escape sequences)
        if [[ $key == $'\x1b' ]]; then
            read -rsn2 key
            case $key in
                '[A') # Up arrow
                    ((selected--))
                    if [ $selected -lt 0 ]; then
                        selected=$((${#options[@]} - 1))
                    fi
                    ;;
                '[B') # Down arrow
                    ((selected++))
                    if [ $selected -ge ${#options[@]} ]; then
                        selected=0
                    fi
                    ;;
            esac
        elif [[ $key == "" ]]; then
            # Enter pressed
            break
        fi
        
        # Move cursor back up
        for i in "${!options[@]}"; do
            tput cuu1
            tput el
        done
    done
    
    # Show cursor
    tput cnorm
    
    echo $selected
}

# Progress bar
show_progress() {
    local current=$1
    local total=$2
    local width=50
    local percentage=$((current * 100 / total))
    local filled=$((current * width / total))
    local empty=$((width - filled))
    
    printf "\r${CYAN}["
    printf "%${filled}s" | tr ' ' '█'
    printf "%${empty}s" | tr ' ' '░'
    printf "] ${WHITE}%3d%%${NC}" $percentage
}

# Generate secure random token
generate_token() {
    openssl rand -base64 32 | tr -d '/+=' | head -c 32
}

#===============================================================================
# SYSTEM CHECKS
#===============================================================================

check_os() {
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        if [ -f /etc/os-release ]; then
            . /etc/os-release
            OS=$NAME
            VER=$VERSION_ID
            return 0
        fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        OS="macOS"
        VER=$(sw_vers -productVersion)
        return 0
    fi
    return 1
}

check_root() {
    if [ "$EUID" -eq 0 ]; then
        return 0
    fi
    return 1
}

check_sudo() {
    if sudo -n true 2>/dev/null; then
        return 0
    fi
    return 1
}

check_node() {
    if command -v node &> /dev/null; then
        local version=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
        if [ "$version" -ge 22 ]; then
            return 0
        fi
    fi
    return 1
}

check_docker() {
    if command -v docker &> /dev/null; then
        if docker ps &> /dev/null; then
            return 0
        fi
    fi
    return 1
}

check_ufw() {
    if command -v ufw &> /dev/null; then
        return 0
    fi
    return 1
}

check_moltbot() {
    if command -v moltbot &> /dev/null; then
        return 0
    fi
    return 1
}

check_tailscale() {
    if command -v tailscale &> /dev/null; then
        return 0
    fi
    return 1
}

#===============================================================================
# INSTALLATION FUNCTIONS
#===============================================================================

install_nodejs() {
    print_step "Installing Node.js 22..."
    
    if [[ "$OS" == *"Ubuntu"* ]] || [[ "$OS" == *"Debian"* ]]; then
        curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash - > /dev/null 2>&1
        sudo apt-get install -y nodejs > /dev/null 2>&1
    elif [[ "$OS" == "macOS" ]]; then
        if command -v brew &> /dev/null; then
            brew install node@22 > /dev/null 2>&1
        else
            print_error "Please install Homebrew first: https://brew.sh"
            exit 1
        fi
    fi
    
    if check_node; then
        print_success "Node.js $(node --version) installed"
    else
        print_error "Failed to install Node.js"
        exit 1
    fi
}

install_docker() {
    print_step "Installing Docker..."
    
    if [[ "$OS" == *"Ubuntu"* ]] || [[ "$OS" == *"Debian"* ]]; then
        curl -fsSL https://get.docker.com | sudo sh > /dev/null 2>&1
        sudo usermod -aG docker $USER
        print_success "Docker installed"
        print_warning "You may need to log out and back in for Docker permissions"
    elif [[ "$OS" == "macOS" ]]; then
        print_info "Please install Docker Desktop from: https://docker.com/products/docker-desktop"
        print_info "Press Enter when Docker is installed and running..."
        read -r
    fi
}

install_ufw() {
    print_step "Installing UFW firewall..."
    sudo apt-get update > /dev/null 2>&1
    sudo apt-get install -y ufw > /dev/null 2>&1
    print_success "UFW installed"
}

install_tailscale() {
    print_step "Installing Tailscale..."
    curl -fsSL https://tailscale.com/install.sh | sh > /dev/null 2>&1
    print_success "Tailscale installed"
}

install_moltbot() {
    print_step "Installing MoltBot..."
    npm install -g moltbot@latest > /dev/null 2>&1
    print_success "MoltBot $(moltbot --version 2>/dev/null || echo 'latest') installed"
}

#===============================================================================
# SECURITY CONFIGURATION
#===============================================================================

configure_firewall() {
    print_section "🔥 Firewall Configuration"
    
    if [[ "$OS" != *"Ubuntu"* ]] && [[ "$OS" != *"Debian"* ]]; then
        print_warning "Automatic firewall setup only available on Ubuntu/Debian"
        print_info "Please configure your firewall manually to:"
        echo "  • Allow SSH (port 22)"
        echo "  • Allow Tailscale (port 41641/udp) if using"
        echo "  • Block everything else incoming"
        return
    fi
    
    echo -e "${GRAY}This will configure your firewall to only allow SSH connections.${NC}"
    echo -e "${GRAY}All other incoming traffic will be blocked for security.${NC}"
    echo ""
    
    if ask_yes_no "Configure firewall now?" "y"; then
        # Reset UFW
        sudo ufw --force reset > /dev/null 2>&1
        
        # Set defaults
        run_with_spinner "Setting firewall defaults" sudo ufw default deny incoming
        run_with_spinner "Allowing outgoing traffic" sudo ufw default allow outgoing
        
        # Allow SSH
        run_with_spinner "Allowing SSH access" sudo ufw allow ssh
        
        # Allow Tailscale if installed
        if check_tailscale; then
            run_with_spinner "Allowing Tailscale" sudo ufw allow 41641/udp
        fi
        
        # Fix Docker UFW bypass
        print_step "Fixing Docker firewall bypass..."
        
        if ! grep -q "DOCKER-USER" /etc/ufw/after.rules 2>/dev/null; then
            sudo tee -a /etc/ufw/after.rules > /dev/null << 'EOF'

# BEGIN DOCKER-UFW - Prevent Docker from bypassing firewall
*filter
:DOCKER-USER - [0:0]
-A DOCKER-USER -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
-A DOCKER-USER -i lo -j ACCEPT
-A DOCKER-USER -j DROP
COMMIT
# END DOCKER-UFW
EOF
            print_success "Docker firewall rules added"
        else
            print_info "Docker firewall rules already present"
        fi
        
        # Enable firewall
        run_with_spinner "Enabling firewall" sudo ufw --force enable
        
        print_success "Firewall configured!"
        echo ""
        echo -e "${GREEN}Current firewall status:${NC}"
        sudo ufw status
    fi
}

configure_tailscale() {
    print_section "🔐 Tailscale VPN Setup"
    
    echo -e "${GRAY}Tailscale provides secure, encrypted access to your MoltBot${NC}"
    echo -e "${GRAY}without exposing any ports to the public internet.${NC}"
    echo ""
    echo -e "${WHITE}Benefits:${NC}"
    echo "  • Access MoltBot from anywhere securely"
    echo "  • No public ports needed"
    echo "  • Works through firewalls and NAT"
    echo "  • Free for personal use"
    echo ""
    
    if ask_yes_no "Set up Tailscale?" "y"; then
        INSTALL_TAILSCALE=true
        
        if ! check_tailscale; then
            install_tailscale
        fi
        
        echo ""
        print_info "Please authenticate with Tailscale..."
        echo ""
        sudo tailscale up
        
        echo ""
        TAILSCALE_IP=$(tailscale ip -4 2>/dev/null || echo "unknown")
        print_success "Tailscale connected!"
        echo -e "${GREEN}Your Tailscale IP: ${WHITE}${TAILSCALE_IP}${NC}"
        echo ""
        print_tip "Use this IP to access MoltBot from your other devices"
    fi
}

#===============================================================================
# MOLTBOT CONFIGURATION
#===============================================================================

configure_model() {
    print_section "🤖 AI Model Configuration"
    
    echo -e "${GRAY}MoltBot needs an AI model to power its intelligence.${NC}"
    echo -e "${GRAY}You'll be using Kimi K2.5 via OpenRouter.${NC}"
    echo ""
    
    echo -e "${WHITE}About Kimi K2.5:${NC}"
    echo "  • Powerful 1 trillion parameter model"
    echo "  • Excellent for coding and agentic tasks"
    echo "  • Cost: ~\$0.60 per million input tokens"
    echo "  • 262K context window"
    echo ""
    
    echo -e "${CYAN}To get your OpenRouter API key:${NC}"
    echo "  1. Go to ${BLUE}https://openrouter.ai${NC}"
    echo "  2. Create an account (or sign in)"
    echo "  3. Go to ${BLUE}Keys${NC} in the dashboard"
    echo "  4. Click ${BLUE}Create Key${NC}"
    echo "  5. Copy the key (starts with sk-or-...)"
    echo ""
    
    while true; do
        echo -ne "${WHITE}Paste your OpenRouter API key: ${NC}"
        read -rs OPENROUTER_API_KEY
        echo ""
        
        if [[ "$OPENROUTER_API_KEY" =~ ^sk-or- ]]; then
            print_success "API key format looks correct"
            break
        else
            print_error "API key should start with 'sk-or-'"
            print_tip "Make sure you copied the entire key"
        fi
    done
}

configure_security_level() {
    print_section "🛡️ Security Level"
    
    echo -e "${GRAY}Choose how locked-down you want your MoltBot to be.${NC}"
    echo -e "${GRAY}You can always adjust these settings later.${NC}"
    echo ""
    
    echo -e "${GREEN}🔒 Maximum Security (Recommended)${NC}"
    echo "   • All tools run in sandboxed containers"
    echo "   • Read-only access to files"
    echo "   • No browser automation"
    echo "   • Requires approval for new contacts"
    echo ""
    
    echo -e "${YELLOW}⚖️  Balanced Security${NC}"
    echo "   • Sandboxed tool execution"
    echo "   • Read/write access to designated folder"
    echo "   • Web search enabled"
    echo "   • Requires approval for new contacts"
    echo ""
    
    echo -e "${RED}⚠️  Minimal Security (Not Recommended)${NC}"
    echo "   • Tools run directly on host"
    echo "   • Full file access"
    echo "   • All features enabled"
    echo "   • Higher risk of issues"
    echo ""
    
    local options=("🔒 Maximum Security (Recommended)" "⚖️  Balanced Security" "⚠️  Minimal Security")
    local selection=$(select_option "Select security level:" "${options[@]}")
    
    case $selection in
        0) SECURITY_LEVEL="maximum" ;;
        1) SECURITY_LEVEL="balanced" ;;
        2) SECURITY_LEVEL="minimal" ;;
    esac
    
    echo ""
    print_success "Security level set to: $SECURITY_LEVEL"
}

configure_web_access() {
    print_section "🌐 Internet Access"
    
    echo -e "${GRAY}MoltBot can search the web to answer questions.${NC}"
    echo -e "${GRAY}This adds capability but also some risk.${NC}"
    echo ""
    
    if [ "$SECURITY_LEVEL" = "minimal" ]; then
        ENABLE_WEB_SEARCH=true
        print_info "Web search enabled (minimal security mode)"
        return
    fi
    
    echo -e "${WHITE}Web search allows MoltBot to:${NC}"
    echo "  • Look up current information"
    echo "  • Research topics for you"
    echo "  • Find answers to questions"
    echo ""
    
    echo -e "${YELLOW}Potential risks:${NC}"
    echo "  • May visit malicious websites"
    echo "  • Could leak context through search queries"
    echo "  • Uses additional API costs (Brave Search)"
    echo ""
    
    if ask_yes_no "Enable web search?" "n"; then
        ENABLE_WEB_SEARCH=true
        
        echo ""
        echo -e "${CYAN}To get a Brave Search API key (free tier available):${NC}"
        echo "  1. Go to ${BLUE}https://brave.com/search/api/${NC}"
        echo "  2. Sign up for an account"
        echo "  3. Create an API key"
        echo ""
        
        if ask_yes_no "Do you have a Brave Search API key?" "n"; then
            echo -ne "${WHITE}Paste your Brave Search API key: ${NC}"
            read -rs BRAVE_API_KEY
            echo ""
            print_success "Brave Search configured"
        else
            print_info "Web search will be enabled without Brave (limited functionality)"
        fi
    else
        print_info "Web search disabled for security"
    fi
}

configure_channels() {
    print_section "📱 Messaging Channels"
    
    echo -e "${GRAY}Choose which apps you want to connect to MoltBot.${NC}"
    echo -e "${GRAY}You'll set up each one after installation.${NC}"
    echo ""
    
    # WhatsApp
    echo -e "${GREEN}WhatsApp${NC}"
    echo "  Connect MoltBot to a WhatsApp account"
    echo "  (Requires a phone number - use a dedicated one!)"
    echo ""
    
    if ask_yes_no "Enable WhatsApp?" "y"; then
        ENABLE_WHATSAPP=true
        
        echo ""
        echo -e "${YELLOW}⚠️  Important Security Notice${NC}"
        echo ""
        echo "  DO NOT use your personal WhatsApp number!"
        echo ""
        echo "  Instead, get a dedicated number from:"
        echo "  • Google Voice (free, US only)"
        echo "  • Twilio (~\$1/month)"
        echo "  • A cheap prepaid SIM"
        echo ""
        print_tip "This protects your personal contacts and conversations"
        echo ""
        read -p "Press Enter to continue..."
    fi
    
    echo ""
    
    # Telegram
    echo -e "${BLUE}Telegram${NC}"
    echo "  Connect MoltBot as a Telegram bot"
    echo ""
    
    if ask_yes_no "Enable Telegram?" "n"; then
        ENABLE_TELEGRAM=true
    fi
}

generate_config() {
    print_section "⚙️  Generating Configuration"
    
    # Generate secure gateway token
    GATEWAY_TOKEN=$(generate_token)
    
    print_step "Creating secure configuration..."
    
    # Create config directory
    mkdir -p "$CONFIG_DIR"
    chmod 700 "$CONFIG_DIR"
    
    # Build configuration based on security level
    local sandbox_mode="all"
    local workspace_access="ro"
    local elevated_allow="[]"
    local browser_enabled="false"
    
    case $SECURITY_LEVEL in
        "maximum")
            sandbox_mode="all"
            workspace_access="ro"
            elevated_allow="[]"
            browser_enabled="false"
            ;;
        "balanced")
            sandbox_mode="non-main"
            workspace_access="rw"
            elevated_allow="[]"
            browser_enabled="false"
            ;;
        "minimal")
            sandbox_mode="off"
            workspace_access="rw"
            elevated_allow='["*"]'
            browser_enabled="true"
            ;;
    esac
    
    # Build web tools config
    local web_config=""
    if [ "$ENABLE_WEB_SEARCH" = true ]; then
        if [ -n "$BRAVE_API_KEY" ]; then
            web_config='"web": {
      "search": {
        "enabled": true,
        "provider": "brave",
        "apiKey": "'"$BRAVE_API_KEY"'"
      },
      "fetch": {
        "enabled": true,
        "timeout": 30000,
        "maxSize": 5242880
      }
    },'
        else
            web_config='"web": {
      "search": {
        "enabled": true
      },
      "fetch": {
        "enabled": true,
        "timeout": 30000,
        "maxSize": 5242880
      }
    },'
        fi
    else
        web_config='"web": {
      "search": { "enabled": false },
      "fetch": { "enabled": false }
    },'
    fi
    
    # Build channels config
    local channels_config='"channels": {'
    
    if [ "$ENABLE_WHATSAPP" = true ]; then
        channels_config+='"whatsapp": {
      "dmPolicy": "pairing",
      "groupPolicy": "allowlist",
      "groupAllowFrom": [],
      "groups": {
        "*": {
          "requireMention": true,
          "enabled": false
        }
      }
    }'
    fi
    
    if [ "$ENABLE_TELEGRAM" = true ]; then
        if [ "$ENABLE_WHATSAPP" = true ]; then
            channels_config+=','
        fi
        channels_config+='"telegram": {
      "dmPolicy": "pairing",
      "groups": {
        "*": { "requireMention": true }
      }
    }'
    fi
    
    channels_config+='}'
    
    # Write configuration file
    cat > "$CONFIG_FILE" << EOF
{
  "env": {
    "OPENROUTER_API_KEY": "$OPENROUTER_API_KEY"
  },
  "gateway": {
    "mode": "local",
    "bind": "loopback",
    "port": 18789,
    "auth": {
      "mode": "token",
      "token": "$GATEWAY_TOKEN"
    },
    "controlUi": {
      "allowInsecureAuth": false
    }
  },
  "discovery": {
    "mdns": {
      "mode": "minimal"
    }
  },
  "agents": {
    "defaults": {
      "model": {
        "primary": "openrouter/moonshotai/kimi-k2.5"
      },
      "sandbox": {
        "mode": "$sandbox_mode",
        "scope": "session",
        "workspaceAccess": "$workspace_access",
        "image": "node:22-slim"
      }
    }
  },
  "tools": {
    "elevated": {
      "allowFrom": $elevated_allow
    },
    "exec": {
      "host": "sandbox"
    },
    $web_config
    "browser": {
      "enabled": $browser_enabled
    }
  },
  $channels_config,
  "logging": {
    "redactSensitive": "tools"
  }
}
EOF
    
    # Set secure permissions
    chmod 600 "$CONFIG_FILE"
    
    print_success "Configuration created!"
    
    # Save gateway token for user
    echo ""
    echo -e "${CYAN}╔═══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║${NC}  ${WHITE}IMPORTANT: Save your Gateway Token${NC}                          ${CYAN}║${NC}"
    echo -e "${CYAN}╠═══════════════════════════════════════════════════════════════╣${NC}"
    echo -e "${CYAN}║${NC}                                                               ${CYAN}║${NC}"
    echo -e "${CYAN}║${NC}  ${YELLOW}$GATEWAY_TOKEN${NC}  ${CYAN}║${NC}"
    echo -e "${CYAN}║${NC}                                                               ${CYAN}║${NC}"
    echo -e "${CYAN}║${NC}  You'll need this to access the web dashboard.               ${CYAN}║${NC}"
    echo -e "${CYAN}║${NC}  Store it somewhere safe!                                    ${CYAN}║${NC}"
    echo -e "${CYAN}╚═══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    read -p "Press Enter when you've saved your token..."
}

#===============================================================================
# POST-INSTALLATION
#===============================================================================

run_security_audit() {
    print_section "🔍 Security Audit"
    
    print_step "Running security checks..."
    echo ""
    
    if check_moltbot; then
        moltbot security audit 2>/dev/null || true
    fi
    
    echo ""
    print_success "Security audit complete!"
}

setup_channels() {
    print_section "📱 Channel Setup"
    
    if [ "$ENABLE_WHATSAPP" = true ]; then
        echo -e "${GREEN}Setting up WhatsApp...${NC}"
        echo ""
        echo "  1. Make sure you have WhatsApp installed on a phone"
        echo "     with your DEDICATED number (not personal!)"
        echo ""
        echo "  2. When you see the QR code:"
        echo "     • Open WhatsApp on your phone"
        echo "     • Go to Settings → Linked Devices"
        echo "     • Tap 'Link a Device'"
        echo "     • Scan the QR code"
        echo ""
        
        if ask_yes_no "Ready to set up WhatsApp now?" "y"; then
            echo ""
            print_info "Starting WhatsApp pairing..."
            moltbot channels whatsapp pair 2>/dev/null || {
                print_warning "WhatsApp pairing will happen when you start the gateway"
            }
        else
            print_info "You can set up WhatsApp later with: moltbot channels whatsapp pair"
        fi
    fi
    
    if [ "$ENABLE_TELEGRAM" = true ]; then
        echo ""
        echo -e "${BLUE}Setting up Telegram...${NC}"
        echo ""
        echo "  1. Message @BotFather on Telegram"
        echo "  2. Send /newbot and follow instructions"
        echo "  3. Copy the bot token you receive"
        echo ""
        
        if ask_yes_no "Do you have your Telegram bot token?" "n"; then
            echo -ne "${WHITE}Paste your Telegram bot token: ${NC}"
            read -rs TELEGRAM_TOKEN
            echo ""
            
            # Add to config
            local tmp=$(mktemp)
            jq --arg token "$TELEGRAM_TOKEN" '.channels.telegram.token = $token' "$CONFIG_FILE" > "$tmp" && mv "$tmp" "$CONFIG_FILE"
            chmod 600 "$CONFIG_FILE"
            
            print_success "Telegram configured!"
        else
            print_info "You can set up Telegram later by adding the token to ~/.moltbot/moltbot.json"
        fi
    fi
}

start_moltbot() {
    print_section "🚀 Starting MoltBot"
    
    echo -e "${GRAY}MoltBot will now start running in the background.${NC}"
    echo ""
    
    if ask_yes_no "Start MoltBot now?" "y"; then
        # Try to install as systemd service if available
        if command -v systemctl &> /dev/null && [ -d /etc/systemd/system ]; then
            print_step "Installing as system service..."
            
            sudo tee /etc/systemd/system/moltbot.service > /dev/null << EOF
[Unit]
Description=MoltBot Gateway
After=network.target docker.service
Wants=docker.service

[Service]
Type=simple
User=$USER
WorkingDirectory=$HOME
ExecStart=$(which moltbot) gateway
Restart=always
RestartSec=10
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF
            
            sudo systemctl daemon-reload
            sudo systemctl enable moltbot
            sudo systemctl start moltbot
            
            sleep 3
            
            if sudo systemctl is-active --quiet moltbot; then
                print_success "MoltBot is running as a service!"
                print_tip "Manage with: sudo systemctl {start|stop|restart|status} moltbot"
            else
                print_warning "Service may not have started correctly"
                print_info "Check with: sudo systemctl status moltbot"
            fi
        else
            print_step "Starting MoltBot..."
            moltbot gateway &
            sleep 3
            print_success "MoltBot started!"
            print_warning "MoltBot is running in the background. It will stop if you close this terminal."
            print_tip "Consider setting up a systemd service for persistent operation"
        fi
    else
        print_info "You can start MoltBot later with: moltbot gateway"
    fi
}

print_summary() {
    print_section "✅ Setup Complete!"
    
    local tailscale_ip=$(tailscale ip -4 2>/dev/null || echo "N/A")
    
    echo -e "${GREEN}╔═══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║${NC}  ${WHITE}MoltBot is ready!${NC}                                           ${GREEN}║${NC}"
    echo -e "${GREEN}╚═══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${WHITE}Configuration Summary:${NC}"
    echo ""
    echo -e "  ${CYAN}Security Level:${NC}    $SECURITY_LEVEL"
    echo -e "  ${CYAN}AI Model:${NC}          Kimi K2.5 (via OpenRouter)"
    echo -e "  ${CYAN}Sandboxing:${NC}        $([ "$SECURITY_LEVEL" != "minimal" ] && echo "Enabled ✓" || echo "Disabled")"
    echo -e "  ${CYAN}Web Search:${NC}        $([ "$ENABLE_WEB_SEARCH" = true ] && echo "Enabled" || echo "Disabled")"
    echo -e "  ${CYAN}WhatsApp:${NC}          $([ "$ENABLE_WHATSAPP" = true ] && echo "Enabled" || echo "Disabled")"
    echo -e "  ${CYAN}Telegram:${NC}          $([ "$ENABLE_TELEGRAM" = true ] && echo "Enabled" || echo "Disabled")"
    echo -e "  ${CYAN}Tailscale IP:${NC}      $tailscale_ip"
    echo ""
    echo -e "${WHITE}Access Points:${NC}"
    echo ""
    echo -e "  ${CYAN}Web Dashboard:${NC}     http://127.0.0.1:18789"
    if [ "$tailscale_ip" != "N/A" ]; then
        echo -e "  ${CYAN}Via Tailscale:${NC}     http://$tailscale_ip:18789"
    fi
    echo ""
    echo -e "${WHITE}Useful Commands:${NC}"
    echo ""
    echo -e "  ${GRAY}moltbot gateway${NC}           Start MoltBot"
    echo -e "  ${GRAY}moltbot security audit${NC}    Check security"
    echo -e "  ${GRAY}moltbot pairing list${NC}      View pending approvals"
    echo -e "  ${GRAY}moltbot status${NC}            Check status"
    echo -e "  ${GRAY}moltbot doctor${NC}            Diagnose issues"
    echo ""
    
    if [ "$ENABLE_WHATSAPP" = true ]; then
        echo -e "${YELLOW}Next Steps for WhatsApp:${NC}"
        echo "  1. Send a message to your MoltBot WhatsApp number"
        echo "  2. You'll receive a pairing code"
        echo "  3. Run: moltbot pairing approve whatsapp <CODE>"
        echo ""
    fi
    
    echo -e "${WHITE}Documentation:${NC}     https://docs.molt.bot"
    echo -e "${WHITE}Security Guide:${NC}    https://docs.molt.bot/gateway/security"
    echo ""
    echo -e "${GREEN}Stay safe! 🦞🔐${NC}"
}

#===============================================================================
# MAIN WIZARD
#===============================================================================

main() {
    print_banner
    
    echo -e "${WHITE}Welcome to the MoltBot Secure Setup Wizard!${NC}"
    echo ""
    echo -e "${GRAY}This wizard will help you install MoltBot with${NC}"
    echo -e "${GRAY}security best practices, even if you're not technical.${NC}"
    echo ""
    echo -e "${YELLOW}⚠️  Before continuing, please read:${NC}"
    echo ""
    echo "  • MoltBot will have significant access to your system"
    echo "  • Always use DEDICATED accounts (not personal)"
    echo "  • This wizard prioritizes security over convenience"
    echo "  • You can adjust settings later if needed"
    echo ""
    
    if ! ask_yes_no "Ready to begin?" "y"; then
        echo ""
        print_info "Setup cancelled. Run this script again when ready."
        exit 0
    fi
    
    # System checks
    print_section "🔍 System Check"
    
    check_os
    print_success "Operating System: $OS"
    
    if check_root; then
        print_error "Please don't run as root. Use a regular user with sudo access."
        exit 1
    fi
    print_success "Running as regular user"
    
    if ! check_sudo; then
        print_error "You need sudo access. Please run: sudo -v"
        exit 1
    fi
    print_success "Sudo access available"
    
    # Install dependencies
    print_section "📦 Installing Dependencies"
    
    if ! check_node; then
        install_nodejs
    else
        print_success "Node.js $(node --version) already installed"
    fi
    
    if ! check_docker; then
        install_docker
    else
        print_success "Docker already installed"
    fi
    
    if ! check_ufw && [[ "$OS" == *"Ubuntu"* ]]; then
        install_ufw
    fi
    
    if ! check_moltbot; then
        install_moltbot
    else
        print_success "MoltBot already installed"
    fi
    
    # Security configuration
    configure_firewall
    configure_tailscale
    
    # MoltBot configuration
    configure_model
    configure_security_level
    configure_web_access
    configure_channels
    generate_config
    
    # Post-installation
    setup_channels
    run_security_audit
    start_moltbot
    
    # Summary
    print_summary
}

# Run main function
main "$@"
