# MoltBot Security-First Setup Guide
## Using Kimi K2.5 via OpenRouter with Full Hardening

**Author:** Claude  
**Date:** January 2026  
**Version:** 1.0

---

## ⚠️ Critical Security Notice

Before proceeding, understand the risks. Recent security research has identified significant concerns with MoltBot deployments:

- **Hundreds of exposed instances** found via Shodan with unauthenticated admin ports
- **Plaintext credential storage** in Markdown and JSON files
- **Supply chain risks** with malicious skills on ClawdHub
- **InfoStealer targeting** - tools like RedLine, Lumma, and Vidar are actively adapting to target MoltBot's local storage

This guide prioritizes security at every step. Follow it exactly.

---

## Table of Contents

1. [Infrastructure Planning](#1-infrastructure-planning)
2. [Isolated Environment Setup](#2-isolated-environment-setup)
3. [Firewall & Network Security](#3-firewall--network-security)
4. [MoltBot Installation](#4-moltbot-installation)
5. [OpenRouter & Kimi K2.5 Configuration](#5-openrouter--kimi-k25-configuration)
6. [Sandbox Configuration](#6-sandbox-configuration)
7. [Credential Isolation Strategy](#7-credential-isolation-strategy)
8. [Internet Access with Risk Mitigation](#8-internet-access-with-risk-mitigation)
9. [Channel Security (WhatsApp, Email)](#9-channel-security-whatsapp-email)
10. [Monitoring & Incident Response](#10-monitoring--incident-response)
11. [Ongoing Maintenance](#11-ongoing-maintenance)

---

## 1. Infrastructure Planning

### Recommended Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│  YOUR NETWORK                                                   │
│  ┌────────────────────────────────────────────────────────────┐│
│  │  Isolated VM / VPS (Ubuntu 24.04)                          ││
│  │  ┌─────────────────────────────────────────────────────┐  ││
│  │  │  Docker Container                                    │  ││
│  │  │  ┌─────────────────────────────────────────────────┐│  ││
│  │  │  │  MoltBot Gateway                                ││  ││
│  │  │  │  - Loopback binding only (127.0.0.1)           ││  ││
│  │  │  │  - Token authentication required               ││  ││
│  │  │  │  - Tool sandboxing enabled                     ││  ││
│  │  │  └─────────────────────────────────────────────────┘│  ││
│  │  └─────────────────────────────────────────────────────┘  ││
│  │  UFW Firewall: Only SSH (22) exposed                       ││
│  └────────────────────────────────────────────────────────────┘│
│                              │                                  │
│                    Tailscale VPN (encrypted tunnel)            │
│                              │                                  │
│  ┌───────────────────────────┴──────────────────────────────┐ │
│  │  Your Device (access via Tailscale IP only)              │ │
│  └──────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

### Why This Architecture?

| Component | Security Benefit |
|-----------|------------------|
| Isolated VM/VPS | Blast radius limited - if compromised, main system untouched |
| Docker Container | Additional process isolation layer |
| Loopback Binding | Gateway never exposed to network directly |
| Tailscale | Encrypted access, no public ports needed |
| Dedicated User | Principle of least privilege |

### Hardware Requirements

MoltBot itself is lightweight:
- **Minimum:** 2 vCPU, 4GB RAM
- **Recommended:** 2 vCPU, 4GB RAM, 20GB SSD
- **Cost:** ~$24/month on DigitalOcean, Hetzner, or similar

---

## 2. Isolated Environment Setup

### Option A: VPS Setup (Recommended)

Choose a provider: DigitalOcean, Hetzner, Vultr, or Linode.

```bash
# After creating Ubuntu 24.04 droplet, SSH in
ssh root@YOUR_VPS_IP

# Update system
apt update && apt upgrade -y

# Create dedicated non-root user
adduser moltbot
usermod -aG sudo moltbot

# Switch to new user
su - moltbot
```

### Option B: Local VM Setup

If using your existing machine, create an isolated VM:

```bash
# Using multipass (cross-platform)
multipass launch 24.04 --name moltbot-vm --cpus 2 --memory 4G --disk 20G
multipass shell moltbot-vm
```

### Install Required Dependencies

```bash
# Install Node.js 22+
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs

# Verify
node --version  # Should be 22.x or higher

# Install Docker (for sandboxing)
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker $USER
newgrp docker

# Install essential tools
sudo apt install -y git curl ufw fail2ban
```

---

## 3. Firewall & Network Security

### UFW Configuration

```bash
# Set default policies (deny all incoming, allow outgoing)
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw default deny routed

# Allow SSH (essential for access)
sudo ufw allow ssh

# If using Tailscale (recommended)
sudo ufw allow 41641/udp comment 'Tailscale'

# DO NOT open port 18789 publicly - access via Tailscale only

# Enable firewall
sudo ufw enable

# Verify
sudo ufw status verbose
```

**Expected output:**
```
Status: active
Logging: on (low)
Default: deny (incoming), allow (outgoing), deny (routed)

To                         Action      From
--                         ------      ----
22/tcp                     ALLOW IN    Anywhere
41641/udp                  ALLOW IN    Anywhere (Tailscale)
```

### Prevent Docker from Bypassing UFW

Docker can bypass UFW by default. Fix this:

```bash
# Create custom iptables rules
sudo nano /etc/ufw/after.rules
```

Add at the end:
```
# BEGIN DOCKER-UFW
*filter
:DOCKER-USER - [0:0]
-A DOCKER-USER -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT
-A DOCKER-USER -i lo -j ACCEPT
-A DOCKER-USER -j DROP
COMMIT
# END DOCKER-UFW
```

```bash
# Restart UFW
sudo ufw reload
```

### Install Tailscale (Strongly Recommended)

Tailscale provides secure, encrypted access without exposing ports:

```bash
# Install Tailscale
curl -fsSL https://tailscale.com/install.sh | sh

# Authenticate
sudo tailscale up

# Note your Tailscale IP
tailscale ip
```

---

## 4. MoltBot Installation

### Install MoltBot

```bash
# Install globally
npm install -g moltbot@latest

# Verify installation
moltbot --version
```

### Secure Directory Permissions

```bash
# Create config directory with secure permissions
mkdir -p ~/.moltbot
chmod 700 ~/.moltbot
```

### Run Onboarding Wizard

```bash
# Start the wizard
moltbot onboard
```

When prompted:
- **Auth choice:** Select `apiKey`
- **Token provider:** Select `openrouter` 
- **Model:** We'll configure Kimi K2.5 in the next section
- **Gateway service:** Yes, install as systemd service
- **Channels:** Configure WhatsApp/Telegram as needed (see Section 9)

---

## 5. OpenRouter & Kimi K2.5 Configuration

### Get Your OpenRouter API Key

1. Go to https://openrouter.ai
2. Create an account
3. Navigate to **Keys** and create a new API key
4. Copy the key (starts with `sk-or-...`)

### Configure MoltBot for OpenRouter

Create/edit the configuration file:

```bash
nano ~/.moltbot/moltbot.json
```

Add this configuration:

```json
{
  "env": {
    "OPENROUTER_API_KEY": "sk-or-YOUR-KEY-HERE"
  },
  "agents": {
    "defaults": {
      "model": {
        "primary": "openrouter/moonshotai/kimi-k2.5"
      }
    }
  }
}
```

### Secure the Config File

```bash
chmod 600 ~/.moltbot/moltbot.json
```

### Alternative: Environment Variable (More Secure)

Instead of storing in config, use environment variables:

```bash
# Add to your shell profile
echo 'export OPENROUTER_API_KEY="sk-or-YOUR-KEY-HERE"' >> ~/.bashrc
source ~/.bashrc
```

Then update config:

```json
{
  "agents": {
    "defaults": {
      "model": {
        "primary": "openrouter/moonshotai/kimi-k2.5"
      }
    }
  }
}
```

### Kimi K2.5 Model Notes

| Property | Value |
|----------|-------|
| Model ID | `moonshotai/kimi-k2.5` |
| Context | 262K tokens |
| Input Cost | $0.60 per million tokens |
| Output Cost | $3.00 per million tokens |
| Strengths | Visual coding, agentic tasks, tool-calling |

---

## 6. Sandbox Configuration

This is **critical** for security. Sandboxing runs tool execution inside Docker containers, limiting damage from prompt injection.

### Full Security Configuration

Edit `~/.moltbot/moltbot.json`:

```json
{
  "env": {
    "OPENROUTER_API_KEY": "sk-or-YOUR-KEY-HERE"
  },
  "gateway": {
    "mode": "local",
    "bind": "loopback",
    "port": 18789,
    "auth": {
      "mode": "token",
      "token": "YOUR-STRONG-RANDOM-TOKEN-32-CHARS"
    },
    "controlUi": {
      "allowInsecureAuth": false
    }
  },
  "discovery": {
    "mdns": {
      "mode": "minimal"
    }
  },
  "agents": {
    "defaults": {
      "model": {
        "primary": "openrouter/moonshotai/kimi-k2.5"
      },
      "sandbox": {
        "mode": "all",
        "scope": "session",
        "workspaceAccess": "ro",
        "image": "node:22-slim"
      }
    }
  },
  "tools": {
    "elevated": {
      "allowFrom": []
    },
    "exec": {
      "host": "sandbox"
    }
  },
  "channels": {
    "whatsapp": {
      "dmPolicy": "pairing",
      "groups": {
        "*": {
          "requireMention": true
        }
      }
    }
  },
  "logging": {
    "redactSensitive": "tools"
  }
}
```

### Generate Secure Gateway Token

```bash
# Generate a cryptographically secure random token
openssl rand -base64 32
```

Copy the output and paste it as your gateway token.

### Sandbox Options Explained

| Setting | Value | Security Benefit |
|---------|-------|------------------|
| `mode: "all"` | Sandbox all sessions | Maximum isolation |
| `scope: "session"` | Per-session containers | Prevents cross-session leakage |
| `workspaceAccess: "ro"` | Read-only workspace | Prevents file modification |
| `elevated.allowFrom: []` | No elevated access | Blocks host command execution |

---

## 7. Credential Isolation Strategy

### Create Dedicated Accounts

**DO NOT** use your personal accounts. Create separate identities:

#### Dedicated Email
1. Create a new Gmail/ProtonMail account specifically for MoltBot
2. Use a strong, unique password
3. Enable 2FA but note MoltBot may need app passwords

#### Dedicated Phone Number (for WhatsApp)
Options:
- **Google Voice** (free, US only)
- **Twilio** (~$1/month)
- **Prepaid SIM** on a secondary phone

#### Dedicated WhatsApp
1. Install WhatsApp on a secondary device or use WhatsApp Web
2. Register with your dedicated phone number
3. This account should have **no personal contacts**

### Credential Storage Security

MoltBot stores credentials in plaintext. Mitigate with:

```bash
# Ensure correct permissions
chmod 700 ~/.moltbot
chmod 600 ~/.moltbot/moltbot.json
chmod -R 600 ~/.moltbot/credentials/

# Consider full-disk encryption on VPS
# Most providers offer this during droplet creation
```

### What Gets Stored

| File | Contents | Risk |
|------|----------|------|
| `~/.moltbot/moltbot.json` | API keys, tokens | HIGH |
| `~/.moltbot/credentials/whatsapp/*/creds.json` | WhatsApp session | HIGH |
| `~/.moltbot/agents/*/agent/auth-profiles.json` | OAuth tokens | HIGH |
| `~/.moltbot/agents/*/sessions/*.jsonl` | Chat transcripts | MEDIUM |

---

## 8. Internet Access with Risk Mitigation

Since you want internet access, here's how to enable it safely:

### Restricted Web Tools Configuration

Update your `moltbot.json`:

```json
{
  "tools": {
    "web": {
      "search": {
        "enabled": true,
        "provider": "brave",
        "apiKey": "YOUR-BRAVE-SEARCH-API-KEY"
      },
      "fetch": {
        "enabled": true,
        "timeout": 30000,
        "maxSize": 5242880
      }
    },
    "browser": {
      "enabled": false
    }
  }
}
```

### Why This Configuration?

| Tool | Status | Reason |
|------|--------|--------|
| `web_search` | ✅ Enabled | Lower risk - returns summaries only |
| `web_fetch` | ✅ Enabled (limited) | Medium risk - size/timeout limited |
| `browser` | ❌ Disabled | HIGH RISK - full browser control |

### Get Brave Search API Key

1. Go to https://brave.com/search/api/
2. Sign up for the free tier (2,000 queries/month)
3. Create an API key
4. Add to config

### Network Egress Monitoring (Advanced)

Monitor outbound connections from the MoltBot container:

```bash
# Install monitoring tools
sudo apt install -y nethogs iftop

# Watch real-time connections
sudo nethogs

# Log all connections (for forensics)
sudo apt install -y conntrack
sudo conntrack -E -o timestamp >> /var/log/moltbot-connections.log &
```

### Outbound Firewall Rules (Optional - More Restrictive)

If you want to limit which domains MoltBot can reach:

```bash
# Install ipset for domain blocking
sudo apt install -y ipset

# Create allowlist of domains (example)
sudo ipset create moltbot_allowed hash:net

# Add allowed IPs (OpenRouter, Brave Search, etc.)
# Note: You'll need to resolve and add IPs manually
sudo ipset add moltbot_allowed 104.18.0.0/16  # Cloudflare (OpenRouter)
```

---

## 9. Channel Security (WhatsApp, Email)

### WhatsApp Security Configuration

```json
{
  "channels": {
    "whatsapp": {
      "dmPolicy": "pairing",
      "groupPolicy": "allowlist",
      "groupAllowFrom": [],
      "groups": {
        "*": {
          "requireMention": true,
          "enabled": false
        }
      }
    }
  }
}
```

### Understanding DM Policies

| Policy | Behavior | Security Level |
|--------|----------|----------------|
| `disabled` | Ignores all DMs | Highest |
| `pairing` | Requires approval code | High (Recommended) |
| `allowlist` | Only pre-approved contacts | Medium |
| `open` | Anyone can message | **DANGEROUS** |

### Pair a Contact (After Setup)

```bash
# List pending pairing requests
moltbot pairing list whatsapp

# Approve a specific code
moltbot pairing approve whatsapp ABC123
```

### Email Integration (If Needed)

For Gmail integration, use app-specific passwords:

1. Go to Google Account → Security → 2-Step Verification
2. At the bottom, select "App passwords"
3. Generate a password for "Mail" on "Other (Custom name)"
4. Use this password in MoltBot config (not your main password)

---

## 10. Monitoring & Incident Response

### Regular Security Audits

```bash
# Run the built-in security audit
moltbot security audit --deep

# Run with auto-fix for common issues
moltbot security audit --fix
```

### What the Audit Checks

- DM/group policies (open = bad)
- Elevated tool access
- Network exposure
- File permissions
- Browser control risks
- Plugin/extension security

### Log Monitoring

```bash
# View recent logs
tail -f /tmp/moltbot/moltbot-$(date +%Y-%m-%d).log

# Set up log rotation
sudo nano /etc/logrotate.d/moltbot
```

Add:
```
/tmp/moltbot/*.log {
    daily
    rotate 7
    compress
    missingok
    notifempty
}
```

### Incident Response Checklist

If you suspect compromise:

1. **Stop immediately:**
   ```bash
   moltbot gateway stop
   # or
   sudo systemctl stop moltbot
   ```

2. **Preserve evidence:**
   ```bash
   cp -r ~/.moltbot ~/.moltbot-incident-backup
   ```

3. **Check logs:**
   ```bash
   grep -r "exec\|bash\|shell" ~/.moltbot/agents/*/sessions/*.jsonl
   ```

4. **Rotate credentials:**
   - Change OpenRouter API key
   - Change gateway token
   - Re-link WhatsApp (revoke old session)
   - Change any exposed passwords

5. **Review and harden:**
   ```bash
   moltbot security audit --deep
   ```

---

## 11. Ongoing Maintenance

### Weekly Tasks

```bash
# Check for updates
npm update -g moltbot

# Run security audit
moltbot security audit

# Review session transcripts for anomalies
ls -la ~/.moltbot/agents/*/sessions/
```

### Monthly Tasks

- Review and prune old session logs
- Rotate API keys if possible
- Review connected WhatsApp devices
- Update system packages

```bash
sudo apt update && sudo apt upgrade -y
```

### Backup Strategy

```bash
# Backup config (but not credentials!)
mkdir -p ~/moltbot-backups
cp ~/.moltbot/moltbot.json ~/moltbot-backups/moltbot-config-$(date +%Y%m%d).json

# For full backup (handle with care - contains secrets!)
tar -czf ~/moltbot-backups/moltbot-full-$(date +%Y%m%d).tar.gz ~/.moltbot
chmod 600 ~/moltbot-backups/*.tar.gz
```

---

## Quick Reference Card

### Essential Commands

| Command | Purpose |
|---------|---------|
| `moltbot gateway` | Start the gateway |
| `moltbot gateway stop` | Stop the gateway |
| `moltbot security audit --deep` | Full security check |
| `moltbot doctor` | Diagnose issues |
| `moltbot pairing list whatsapp` | View pending approvals |
| `moltbot pairing approve whatsapp CODE` | Approve contact |
| `moltbot status --all` | System status |

### Security Configuration Summary

```json
{
  "gateway": {
    "bind": "loopback",
    "auth": { "mode": "token", "token": "STRONG_TOKEN" }
  },
  "agents": {
    "defaults": {
      "sandbox": { "mode": "all", "scope": "session", "workspaceAccess": "ro" }
    }
  },
  "tools": {
    "elevated": { "allowFrom": [] },
    "browser": { "enabled": false }
  },
  "channels": {
    "whatsapp": { "dmPolicy": "pairing" }
  },
  "discovery": {
    "mdns": { "mode": "minimal" }
  }
}
```

### Security Checklist Before Going Live

- [ ] Running on isolated VM/VPS (not main machine)
- [ ] UFW firewall enabled with minimal ports
- [ ] Docker UFW bypass fixed
- [ ] Gateway bound to loopback only
- [ ] Strong gateway authentication token set
- [ ] Tailscale installed for remote access
- [ ] Sandboxing enabled (`mode: "all"`)
- [ ] Elevated tools disabled (`allowFrom: []`)
- [ ] Browser control disabled
- [ ] DM policy set to `pairing`
- [ ] mDNS set to `minimal`
- [ ] File permissions set (700 dirs, 600 files)
- [ ] Dedicated WhatsApp account (not personal)
- [ ] Security audit passes clean

---

## Additional Resources

- **Official Docs:** https://docs.molt.bot
- **Security Guide:** https://docs.molt.bot/gateway/security
- **GitHub:** https://github.com/moltbot/moltbot
- **OpenRouter:** https://openrouter.ai/moonshotai/kimi-k2.5

---

*Remember: "There is no 'perfectly secure' setup." The goal is to be deliberate about who can talk to your bot, where it can act, and what it can touch. Start with the smallest access that works, then widen carefully.*
